package co.edu.app;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import co.edu.app.DB.CRUD;

public class MenuProveedor extends AppCompatActivity {
    TextView nombreMaterial, pesoMaterial, direccionMaterial;
    Spinner tipoMaterial;
    Button postear;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_proveedor);
        nombreMaterial = findViewById(R.id.cajaTextoNombreMaterialProveedor);
        pesoMaterial = findViewById(R.id.cajaTextoPesoMaterialProveedor);
        direccionMaterial = findViewById(R.id.cajaTextoDireccionProveedor);
        tipoMaterial = findViewById(R.id.spinner2);
        postear = findViewById(R.id.buttonPost);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);

        postear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CRUD insertProduct = new CRUD(getApplicationContext());
                insertProduct.InsertProduct(nombreMaterial.getText().toString(),tipoMaterial.getSelectedItem().toString() ,pesoMaterial.getText().toString(), direccionMaterial.getText().toString(), "Creado");
                Toast.makeText(MenuProveedor.this, "El pedido ha sido creado", Toast.LENGTH_SHORT).show();
                vaciarCampos();
            }
            private void vaciarCampos(){
                nombreMaterial.setText("");
                pesoMaterial.setText("");
                direccionMaterial.setText("");
            }
        });
    }

}