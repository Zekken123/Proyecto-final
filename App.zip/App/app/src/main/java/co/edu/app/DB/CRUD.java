package co.edu.app.DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

import java.util.ArrayList;

import co.edu.app.Pedido;
import co.edu.app.Usuario;

public class CRUD extends DbHelper{
    Context context;

    public CRUD(@Nullable Context context) {
        super(context);
        this.context = context;
    }

    public long InsertUser(String usuario, String nombre, String apellido, String email, String contraseña, String tipoDeUsuario){
        DbHelper dbHelper = new DbHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        try {
            values.put("IdUsuario", usuario);
            values.put("Nombre", nombre);
            values.put("Apellido", apellido);
            values.put("Email", email);
            values.put("Contraseña", contraseña);
            values.put("Tipo", tipoDeUsuario);
        }catch (Exception e){
            e.toString();
        }
        return db.insert(TABLA_USUARIOS_REGISTRADOS, null, values);
    }

    public long InsertProduct(String nombreProducto,String tipoProducto, String pesoProducto, String direccionProducto, String estadoProducto){
        DbHelper dbHelper = new DbHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        try {
            values.put("NombrePedido", nombreProducto);
            values.put("TipoPedido", tipoProducto);
            values.put("PesoPedido", pesoProducto);
            values.put("DireccionPedido", direccionProducto);
            values.put("EstadoPedido", estadoProducto);
        }catch (Exception e){
            e.toString();
        }
        return db.insert(TABLA_PEDIDOS_PROVEEDOR, null, values);
    }


    public ArrayList<Usuario> selectUser(){
        DbHelper dbHelper = new DbHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ArrayList<Usuario> listaUsuarios = new ArrayList<>();
        Cursor cursorUsuarios = null;
        Usuario usuario = null;
        cursorUsuarios = db.rawQuery("SELECT *  FROM " + TABLA_USUARIOS_REGISTRADOS, null);
        if(cursorUsuarios.moveToFirst()) {
            do {
                usuario = new Usuario(null,null,null,null,null,null);
                usuario.setIdUsuario(cursorUsuarios.getString(0));
                usuario.setNombre(cursorUsuarios.getString(1));
                usuario.setApellido(cursorUsuarios.getString(2));
                usuario.setEmail(cursorUsuarios.getString(3));
                usuario.setContraseña(cursorUsuarios.getString(4));
                usuario.setTipo(cursorUsuarios.getString(5));
                listaUsuarios.add(usuario);
            } while (cursorUsuarios.moveToNext());
        }
        cursorUsuarios.close();
        return listaUsuarios;
    }

    public ArrayList<Pedido> selectPedido(){
        DbHelper dbHelper = new DbHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ArrayList<Pedido> listaPedidos = new ArrayList<>();
        Cursor cursorPedidos = null;
        Pedido pedidos = null;
        cursorPedidos = db.rawQuery("SELECT *  FROM " + TABLA_PEDIDOS_PROVEEDOR, null);
        if(cursorPedidos.moveToFirst()) {
            do {
                System.out.println("Cursor: " + cursorPedidos.getString(5));
                if(cursorPedidos.getString(5).equals("Creado")) {
                    pedidos = new Pedido(null,null,null,null,null, null);
                    pedidos.setIdPedido(cursorPedidos.getString(0));
                    pedidos.setNombrePedido(cursorPedidos.getString(1));
                    pedidos.setTipoPedido(cursorPedidos.getString(2));
                    pedidos.setPesoPedido(cursorPedidos.getString(3));
                    pedidos.setDireccionPedido(cursorPedidos.getString(4));
                    pedidos.setEstadoPedido(cursorPedidos.getString(5));
                    listaPedidos.add(pedidos);
                }
            } while (cursorPedidos.moveToNext());
        }
        cursorPedidos.close();
        return listaPedidos;
    }

    public  void editEstado(int id){
        DbHelper dbHelper = new DbHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        try {
            db.execSQL("UPDATE " + TABLA_PEDIDOS_PROVEEDOR + " SET EstadoPedido = '" + "Tomado'"  +" WHERE IdPedido = '" + id + "'");
        }catch (Exception e){
            e.toString();
        }
    }

    public  void pedidoFinalizado(int id){
        DbHelper dbHelper = new DbHelper(context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        try {
            db.execSQL("UPDATE " + TABLA_PEDIDOS_PROVEEDOR + " SET EstadoPedido = '" + "Finalizado'"  +" WHERE IdPedido = '" + id + "'");
        }catch (Exception e){
            e.toString();
        }
    }
}
