package co.edu.app;

import android.Manifest;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.Random;


public class OdometerService extends Service {

    private static final String PERMISSION_STRING = Manifest.permission.ACCESS_FINE_LOCATION;
    private static final String PERMISSION_STRING_COARSE = Manifest.permission.ACCESS_COARSE_LOCATION;
    //Declaro variable IBInder privada para retornar el objeto IBinder Object
    private final IBinder binder = new OdometerBinder();
    //Declaro variable aleatoria
    //private final Random random = new Random();
    //Declaro una referencia al escucha de servicio de localización
    private LocationListener locationListener;
    //Gestor de localizacion
    private LocationManager locationManager;
    //delcaro vcariable par almacenar distancia
    private static double distance;
    //declaro variable de localizacion para almacenar la ubicación
    private static Location lastLocation = null;


    public OdometerService() {
    }

    //Se ejecuta cuando se instancia el servicio
    //Se ejecuta cuando se instancia el servicio
    public void onCreate() {
        super.onCreate();
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(@NonNull Location location) {
                //código para hacer seguimiento de la distancia
                if(lastLocation == null){
                    lastLocation = location;
                }
                distance += location.distanceTo(lastLocation);
                lastLocation = location;
            }

            @Override
            public void onProviderDisabled(@NonNull String provider) {
                LocationListener.super.onProviderDisabled(provider);
                //código cuando no está disponible el proveedor
            }

            @Override
            public void onProviderEnabled(@NonNull String provider) {
                LocationListener.super.onProviderEnabled(provider);
                //Codigo cuando está disponible el proveedor
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {
                LocationListener.super.onStatusChanged(provider, status, extras);
                //Cuando el estado cambia

            }
        };
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        String provider = locationManager.getBestProvider(new Criteria(), true);
        if(ContextCompat.checkSelfPermission(this, PERMISSION_STRING) == PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(this, PERMISSION_STRING_COARSE) == PackageManager.PERMISSION_GRANTED) {
            if (provider != null) {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                locationManager.requestLocationUpdates(provider, 1, 1, locationListener);
                Log.v("Actualizando", locationManager.getLastKnownLocation(provider).toString());
            }
        }
    }

    @Override
    public void onDestroy(){
        super.onDestroy();
        if(ContextCompat.checkSelfPermission(this, PERMISSION_STRING) == PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(this, PERMISSION_STRING_COARSE) == PackageManager.PERMISSION_GRANTED) {
            if (locationManager != null && locationListener != null) {
                locationManager.removeUpdates(locationListener);
            }
        }
        locationManager = null;
        locationListener = null;
    }




    public class OdometerBinder extends Binder {
        //Enlazar odometer
        OdometerService getOdometer(){
            return OdometerService.this;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        return binder;
    }
    boolean minutos = false;
    //Metodo invocado desde otros componentes para hacer uso del servicio
    public double getDistance(){
        //Random random = new Random();
        //return  random.nextDouble();

        distance += 1;

        return distance;//1609;
    }
}