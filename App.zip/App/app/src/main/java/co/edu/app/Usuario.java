package co.edu.app;

public class Usuario {
    private String IdUsuario, Nombre, Apellido, Email, Contraseña, Tipo;

    public Usuario(String idUsuario, String nombre, String apellido, String email, String contraseña, String tipo) {
        IdUsuario = idUsuario;
        Nombre = nombre;
        Apellido = apellido;
        Email = email;
        Contraseña = contraseña;
        Tipo = tipo;
    }

    public String getIdUsuario() {
        return IdUsuario;
    }
    public void setIdUsuario(String idUsuario) {
        IdUsuario = idUsuario;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String apellido) {
        Apellido = apellido;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getContraseña() {
        return Contraseña;
    }

    public void setContraseña(String contraseña) {
        Contraseña = contraseña;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String tipo) {
        Tipo = tipo;
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "IdUsuario='" + IdUsuario + '\'' +
                ", Nombre='" + Nombre + '\'' +
                ", Apellido='" + Apellido + '\'' +
                ", Email='" + Email + '\'' +
                ", Contraseña='" + Contraseña + '\'' +
                ", Tipo='" + Tipo + '\'' +
                '}';
    }
}
