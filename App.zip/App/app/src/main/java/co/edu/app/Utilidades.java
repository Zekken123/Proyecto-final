package co.edu.app;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Utilidades {
    public static List<List<HashMap<String, String>>> routes = new ArrayList<List<HashMap<String,String>>>();
    public static Punto coordenadas= new Punto();
}
