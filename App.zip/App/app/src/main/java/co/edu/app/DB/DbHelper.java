package co.edu.app.DB;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DbHelper extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 3;
    private static final String DATABASE_NAME = "ReciclarT";
    public static final String TABLA_USUARIOS_REGISTRADOS = "Usuarios_Registrados";
    public static final String TABLA_PEDIDOS_PROVEEDOR = "Pedidos_Realizados";

    public DbHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE " + TABLA_USUARIOS_REGISTRADOS + "(" +
                "IdUsuario TEXT PRIMARY KEY," +
                "Nombre TEXT NOT NULL," +
                "Apellido TEXT NOT NULL," +
                "Email TEXT NOT NULL," +
                "Contraseña TEXT NOT NULL," +
                "Tipo TEXT NOT NULL)"
                );

        sqLiteDatabase.execSQL("CREATE TABLE " + TABLA_PEDIDOS_PROVEEDOR + "(" +
                "IdPedido INTEGER PRIMARY KEY AUTOINCREMENT," +
                "NombrePedido TEXT NOT NULL," +
                "TipoPedido TEXT NOT NULL, " +
                "PesoPedido TEXT NOT NULL," +
                "DireccionPedido TEXT NOT NULL," +
                "EstadoPedido TEXT NOT NULL)"
        );

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
