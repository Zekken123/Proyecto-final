package co.edu.app;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;

import co.edu.app.DB.CRUD;
import co.edu.app.DB.DbHelper;

public class MainActivity extends AppCompatActivity {
    EditText email, contraseña;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DbHelper dataBase = new DbHelper(getApplicationContext());
        email = findViewById(R.id.cajaTextoEmail);
        contraseña = findViewById(R.id.cajaTextoContraseña);

    }

    public void registrarUsuario(View view){
        startActivity(new Intent(getApplicationContext(), CreateAccount.class));
    }

    public void loginusuario(View view){
        boolean encontrado = false;
        CRUD selectUser = new CRUD(getApplicationContext());
        ArrayList<Usuario> usuarios = selectUser.selectUser();
        for(Usuario n : usuarios ){
            if(email.getText().toString().equals(n.getEmail()) && contraseña.getText().toString().equals(n.getContraseña())) {
                Toast.makeText(this, "Bienvenido", Toast.LENGTH_SHORT).show();
                encontrado = true;
                if(n.getTipo().equals("Reciclador")){
                    startActivity(new Intent(getApplicationContext(), MenuReciclador.class));
                }else if(n.getTipo().equals("Proveedor de material reciclable")){
                    startActivity(new Intent(getApplicationContext(), MenuProveedor.class));
                }
                break;
            }
        }
        if(!encontrado){
            Toast.makeText(this, "Los datos no coinciden o el usuario no existe", Toast.LENGTH_SHORT).show();
        }
    }

    public void recoveryPassword(View view){
        startActivity(new Intent(getApplicationContext(), RecuperarContra.class));
    }
}

