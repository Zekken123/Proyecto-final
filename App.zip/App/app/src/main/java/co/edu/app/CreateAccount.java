package co.edu.app;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import co.edu.app.DB.CRUD;

public class CreateAccount extends AppCompatActivity {
    private EditText nombre, apellido, email, identificacion, contraseña, verificarContraseña;
    private Spinner tipoUsuario;
    private Button registrar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        nombre = findViewById(R.id.cajaTextoNombreRegistro);
        apellido = findViewById(R.id.cajaTextoApellidoRegistro);
        email = findViewById(R.id.cajaTextoEmailRegistro);
        identificacion = findViewById(R.id.cajaTextoIdentificaciónregistro);
        contraseña = findViewById(R.id.cajaTextoContraseñaRegistro);
        verificarContraseña = findViewById(R.id.cajaConfirmarContraseñaRegistro);
        tipoUsuario = findViewById(R.id.spinner);
        registrar = findViewById(R.id.botonRegistrarUsuario);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);

        registrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              CRUD insertUser = new CRUD(getApplicationContext());
              if(contraseña.getText().toString().equals(verificarContraseña.getText().toString())) {
                  insertUser.InsertUser(identificacion.getText().toString(), nombre.getText().toString(), apellido.getText().toString(), email.getText().toString(), contraseña.getText().toString(), tipoUsuario.getSelectedItem().toString());
                  Toast.makeText(CreateAccount.this, "El usuario ha sido creado", Toast.LENGTH_SHORT).show();
                  vaciarCampos();
                  startActivity(new Intent(getApplicationContext(), MainActivity.class));
              }else{
                  Toast.makeText(CreateAccount.this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show();
                  }
            }

            private void vaciarCampos(){
                nombre.setText("");
                apellido.setText("");
                email.setText("");
                identificacion.setText("");
                contraseña.setText("");
                verificarContraseña.setText("");
            }
        });
    }
}