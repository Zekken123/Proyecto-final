package co.edu.app;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.maps.model.LatLng;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import co.edu.app.DB.CRUD;

public class MenuReciclador extends AppCompatActivity {
    Spinner pedidos;
    Button botonSeleccionarPedidos, botonFinalizarPedido;
    WebView webView;
    public int id;
    public String direccionPedido;
    TextView tiempo;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_reciclador);
        webView = (WebView) findViewById(R.id.mapa);
        webView.setWebViewClient(new WebViewClient());
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        pedidos = findViewById(R.id.SpinnerProductosBase);
        botonSeleccionarPedidos = findViewById(R.id.buttonSeleccionarPedido);
        botonFinalizarPedido = findViewById(R.id.buttonFinalizarPedido);
        tiempo = findViewById(R.id.mostrarTiempo);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        List <Pedido> listaPedidos = llenarPedidos();
        ArrayAdapter <Pedido> arrayAdapter = new ArrayAdapter<>(getApplicationContext(), androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, listaPedidos);
        pedidos.setAdapter(arrayAdapter);

        pedidos.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                id = Integer.parseInt(((Pedido) adapterView.getSelectedItem()).getIdPedido());
                direccionPedido =  ((Pedido) adapterView.getSelectedItem()).getDireccionPedido();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        botonSeleccionarPedidos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    CRUD editarEstadoPedido = new CRUD(getApplicationContext());
                    editarEstadoPedido.editEstado(id);
                if(id != 0){
                    pedidos.setEnabled(false);
                    Toast.makeText(MenuReciclador.this, "El pedido #" + id + " ha sido tomado", Toast.LENGTH_SHORT).show();
                    Uri.Builder builder = new Uri.Builder();
                    builder.scheme("https")
                            .authority("www.google.com")
                            .appendPath("maps")
                            .appendPath("dir")
                            .appendPath("")
                            .appendQueryParameter("api", "1")
                            .appendQueryParameter("destination", direccionPedido + " Bogotá, Colombia");
                    String url = builder.build().toString();
                    Log.d("Directions", url);
                    webView.loadUrl(url);
                    displayDistance();
                }else {
                    Toast.makeText(MenuReciclador.this, "No hay pedidos aún en lista", Toast.LENGTH_SHORT).show();
                }
            }
        });

        botonFinalizarPedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CRUD editarEstadoPedido = new CRUD(getApplicationContext());
                pedidos = null;
                editarEstadoPedido.pedidoFinalizado(id);
                Toast.makeText(MenuReciclador.this, "El pedido ha sido recogido", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), MenuReciclador.class));
            }
        });
    }



    //Crud
    private List<Pedido> llenarPedidos(){
        List<Pedido> ListaPedidos = new ArrayList<>();
        CRUD selectPedido = new CRUD(getApplicationContext());
        ListaPedidos  = (List) selectPedido.selectPedido();
        for(Pedido n: ListaPedidos){
            System.out.println("Pedidos");
            System.out.println(n.toString());
        }
        return ListaPedidos;
    }
    //Mapa
    @Override
    public void onBackPressed() {
        if(webView.canGoBack()){
            webView.goBack();
        }else {
            super.onBackPressed();
        }
    }

    //Servicio
    OdometerService odometer;
    private boolean bound = false;

    //Declaro objeto conexion a servicio
    private final ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            //Código a jecutar cuando se conecta con el servicio
            OdometerService.OdometerBinder odometerBinder = (OdometerService.OdometerBinder) iBinder;
            odometer = odometerBinder.getOdometer();
            bound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            //código que se ejecuta cuando se desconecta del servicio
            bound = false;
        }
    };

    @Override
    protected void onStart(){
        super.onStart();
        Intent intent = new Intent(this, OdometerService.class);
        bindService(intent, connection, Context.BIND_AUTO_CREATE);
        bound = true;

    }

    protected void onStop(){
        super.onStop();
        if(bound){
            bound = false;
        }

    }

    private void displayDistance(){
        final Handler handler = new Handler();
        handler.post(new Runnable() {
            @Override
            public void run() {
                double distance = 0.0;
                if(bound && odometer != null){
                    distance = odometer.getDistance();
                }
                    @SuppressLint("DefaultLocale") String distanceString = String.format("%.2f", distance) + "s";
                    tiempo.setText(distanceString);
                    handler.postDelayed(this, 1000);
            }
        });
    }
}