package co.edu.app;

public class Pedido {
    private String IdPedido, NombrePedido, TipoPedido, PesoPedido, DireccionPedido, EstadoPedido;


    public Pedido(String idPedido, String nombrePedido, String tipoPedido, String pesoPedido, String direccionPedido, String estadoPedido) {
        IdPedido = idPedido;
        NombrePedido = nombrePedido;
        TipoPedido = tipoPedido;
        PesoPedido = pesoPedido;
        DireccionPedido = direccionPedido;
        EstadoPedido = estadoPedido;
    }

    public String getIdPedido() {
        return IdPedido;
    }

    public String getNombrePedido() {
        return NombrePedido;
    }

    public String getTipoPedido() {
        return TipoPedido;
    }

    public String getPesoPedido() {
        return PesoPedido;
    }

    public String getDireccionPedido() {
        return DireccionPedido;
    }

    public String getEstadoPedido() {
        return EstadoPedido;
    }

    public void setIdPedido(String idPedido) {
        IdPedido = idPedido;
    }

    public void setNombrePedido(String nombrePedido) {
        NombrePedido = nombrePedido;
    }

    public void setTipoPedido(String tipoPedido) {
        TipoPedido = tipoPedido;
    }

    public void setPesoPedido(String pesoPedido) {
        PesoPedido = pesoPedido;
    }

    public void setDireccionPedido(String direccionPedido) {
        DireccionPedido = direccionPedido;
    }

    public void setEstadoPedido(String estadoPedido) {
        EstadoPedido = estadoPedido;
    }

    @Override
    public String toString() {
        return NombrePedido + ",  " + TipoPedido + ",  " + PesoPedido + ",  " + DireccionPedido;

    }
}
