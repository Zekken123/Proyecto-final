package co.edu.app;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

import co.edu.app.DB.CRUD;

public class RecuperarContra extends AppCompatActivity {
    EditText identificacion, nombres, apellidos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recuperar_contra);
        identificacion = findViewById(R.id.cajaTextoNombreMaterialProveedor);
        nombres = findViewById(R.id.nombreRecovery);
        apellidos = findViewById(R.id.cajaTextoPesoMaterialProveedor);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
    }

    public void recoveryPassword(View view){

        boolean encontrado = false;
        CRUD select = new CRUD(getApplicationContext());
        ArrayList<Usuario> usuarios = select.selectUser();
        for(Usuario n : usuarios ){
            if(identificacion.getText().toString().equals(n.getIdUsuario()) && nombres.getText().toString().equals(n.getNombre()) && apellidos.getText().toString().equals(n.getApellido())) {
                Toast.makeText(this, "La contraseña es: " + n.getContraseña(), Toast.LENGTH_SHORT).show();
                encontrado = true;
                break;
            }
        }
        if(!encontrado){
            Toast.makeText(this, "El usuario no existe", Toast.LENGTH_SHORT).show();
        }

    }
}